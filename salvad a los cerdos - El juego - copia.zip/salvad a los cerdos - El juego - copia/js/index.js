/*Ancho y alto del div de fondo de la aplicación */
// VARIABLES GLOBALES
//para saber alto y ancho
ancho_fondo = document.querySelector('.fondo').clientWidth
alto_fondo = document.querySelector('.fondo').clientHeight
var contvivos = 0;

/*clase personaje*/
class Cerdo{
	constructor(id){
		/*funcion random() devuelve valor aleatorio entre -5 y 5*/ 
		const random = () => Math.random() * (15 + 0);
		
		// variable random_posicion_x : Guarda la posicion aleatoria en el eje x dentro de mi ventana
		const random_posicion_x = Math.floor(Math.random()*(ancho_fondo-200))
		// PROPIEDADES		
		this.id = id
		this.vida = 1
		this.top = 0
		this.left = random_posicion_x
		this.velx = 0
		this.vely = random()
		this.estado = 'esperando' //puede valer salvado, muerto, esperando o volando
		this.clon = '' //Guarda el html correspondiente al cerdo
	}

	
	// método Jugar()
	jugar(){
		//Guardamos en this.clon un clon del div #plantilla
		const node = document.querySelector('#plantilla')
		this.clon = node.cloneNode(true);
		//añadimos a this.clon el atributo id correspondiente a la propiedad this.id del objeto
		var id = `jugador${this.id}`;
		this.clon.setAttribute("id", id);
		// cambiamos la propiedad css left para que coincida con this.left
		this.clon.style.left = this.left + 'px';
		//Añado el html de this.clon al div .fondo
		document.querySelector('.fondo').appendChild(this.clon);
		//Añadimos listener de click a this.clon 
		this.clon.addEventListener('click', ()=>{
			//Si click en cerdo...
			if(this.estado == 'volando'){
				//cambiamos this.estado a salvado	
				this.estado = 'salvado';
				document.getElementById(`jugador${this.id}`).classList.add('feliz');
				//incrementamos la propiedad cerdos_salvados del objeto partida
				if(this.estado == 'salvado'){
					contvivos++;
					juego.cerdos_salvados = contvivos;
					//meto en el contrador los cerdos que he salvado 
					document.querySelector('#div_cerdos_salvados').innerHTML = contvivos;
				}
				//Actualizamos el dom para que aparezcan los cerdos salvados en pantalla
				document.querySelector('.fondo').appendChild(this.clon);
				//Cargamos sonido y reproducimos
				//Ponemos temporizador para que al cabo de un segundo se llame al metodo borrarCerdo
				if(this.estado == 'salvado'){
					var tempBorrar = setInterval(()=>{
						this.borrarCerdo();
					}, 1000);
				}
			}
		})
	}
				
	// método matarCerdo()
	matarCerdo() {
		//cambiamos propiedad estado del cerdo a 'muerto'
		this.estado = "muerto";
		//añadimos al clon la clase 'hot'
		this.clon.classList.add("hot");
		//eliminamos la clase 'cerdo'
		this.clon.classList.remove("cerdo");
		//incrementamos la propiedad cerdos_muertos del objeto 'juego'
		juego.cerdos_muertos++;
		//insertamos en pantalla los cerdos muertos
		document.querySelector(".jugador").innerHTML = this.clon;
		//cargamos y reproducimos el sonido del cerdo muerto
	}
		
	// método mover()
	mover(){
		//miramos si el estado del cerdo es 'volando'. En caso afirmativo...
		if(this.estado == 'volando'){
			//comprobamos que el cerdo ha llegado al final de la pantalla. Si es así...
			if(this.top + 102 >= alto_fondo){
				//llamamos al método martarCerdo()
				this.matarCerdo();
			}else{
				//Si aún está volando 
				//incrementamos la posición top del cerdo
				this.top+= this.vely;
				//Actualizamos el propiedad CSS top del clon con el valor this.top
				this.clon.style.top = this.top + 'px';
			}
		}
	}
			
			
	// método borrarCerdo()
	borrarCerdo(){
		//Cambiamos el valor de la propiedad display del cerdo por 'none'
		this.clon.remove('.cerdo');

	}

	//metodo sonido(fuente) //metodo para cargar un archivo 'fuente' y reproducirlo (la fuente debe ser la ruta completa del archivo)
	//sonido(fuente){
	 	// Carga un sonido a través de su fuente y lo inyecta de manera oculta
		//const sonido = document.createElement("audio");
	 	//sonido.src = fuente;
	 	//sonido.setAttribute("preload", "auto");
	 	//sonido.setAttribute("controls", "none");
	 	//sonido.style.display = "none"; // <-- oculto
	 	//document.body.appendChild(sonido);
	 	//return sonido;
	 //}

}


// ******************* clase juego *************************************
class Juego{
	//constructor (no recibe parámetros)
	constructor(arrayCerdos){
		//propiedades:
		this.cerdos = arrayCerdos; 
		this.interval = this.interval; //guardamos referencia al setInterval para poder modificarlo
		this.contadoCerdosLanzar = 0;
		this.tiempo = 30000;//segundos que dura el programa
		this.cerdos_salvados = 0;
		this.cerdos_muertos = 0;
	}
	
	crearInstancias(numCerdos){
		var cont = 0 
		var arrayCerdos = [];
		//for para tantos cerdos como numCerdos
		for(let i = 0; i < numCerdos; i++){
			//Creamos instancia de clase Cerdo con id igual a index y la guardamos en el arrayCerdos
			
			arrayCerdos[i] = new Cerdo(i);
			//creo el estado moviendo.

			arrayCerdos[i].estado = 'esperando';
		
			//Llamamos al método jugar de la instancia
			arrayCerdos[i].jugar();
		}
		return arrayCerdos;
	}

	lanzarCerdo(){

		this.cerdos[this.contadoCerdosLanzar].estado = 'volando';
		//incrementamos
		console.log(this.contadoCerdosLanzar)
		this.contadoCerdosLanzar ++;


	}

	// método play()
	play(){
		// Llamamos al metodo this.crearInstancias y la pasamos por ejemplo 30 cerdos
		this.cerdos = this.crearInstancias(40);
	
		//cambiamos la propiedad display del div .fin (con el texto de entrada) a 'none' para que desaparezca
		document.querySelector('.fin').style.display="none";
		//cambiamos la propiedad display del div .juego (con el juego) a 'block' para que aparezca
		document.querySelector('.juego').style.display="block";
		//ponemos a 0 la variable tiempoCerdo que servirá para lanzar cerdos cada 500 milisegundos
		this.tiempoCerdo = 0;

		//guardo en this.interval un setInterval que se llama cada 50 milisegundos para crear el movimiento de los cerdos
		this.interval = setInterval(() =>{
			//restamos 50 milisegundos a this.tiempo para la cuenta atras
			this.tiempo = this.tiempo - 50
			// incrementamos en 1 la variable tiempoCerdo
			this.tiempoCerdo ++;
			console.log(this.cerdos.length)
			// si tiempoCerdo llega a 10 y el this.contadorCerdosLanzar es menor que la cantidad de cerdos que quedan en el this.arrayCerdos
			if(this.tiempoCerdo == 10  && this.contadoCerdosLanzar < this.cerdos.length){
				//llamamos al método lanzarCerdo()
				this.lanzarCerdo();
				//y ponemos el temporizador de lanzamiento de cerdos a 0
				this.tiempoCerdo = 0;
			}
			//actualizmos los divs con los datos de this.tiempo, this.cerdos_muertos y this.cerdos_salvados
			document.querySelector('#div_contador').innerHTML = Math.floor(this.tiempo/1000);//redondeo a la baja para que salga lo que toca 
			document.querySelector('#div_cerdos_muertos').innerHTML = this.cerdos_muertos;

			//si el contador this.tiempo ha llegado a 0 llamamos al método end()
			if(this.tiempo == 0){
				this.end();
			}
			//recorremos this.arrayCerdos y llamamos a su metodo mover() para que los cerdos vayan cayendo
			this.cerdos.forEach(function(cerdo){
					cerdo.mover();
			})
		 //FIN SETINTERVAL 50 ms equivale a 20 frames/segundo
		}, 50);
		
		//descontar un segundo cada un segundo

	}
	
	// método end()
	end(){
		// limpia el setInterval para parar la animación
		clearInterval(this.interval);
		//Mostramos el div .fin actualizando su propiedad display al valor 'flex'
		document.querySelector('.fin').style.display="flex";
		//Actualizamos el contenido del div .fin con innerHTML insertando el texto que indica los cerdos salvados, muertos, etc
		document.querySelector('.fin').innerHTML = `Has conseguido salvar ${this.cerdos_salvados} cerdos... pero ${this.cerdos_muertos} han pasado a mejor vida`;
	}
}

//Creamos una instancia con nombre 'juego'
var arrayCerditos;
var juego = new Juego(arrayCerditos);
//detectamos click sobre el botón y llamamos a juego.play()
var pulsar = document.querySelector('button');
pulsar.addEventListener('click', () => {
	juego.play();
});
